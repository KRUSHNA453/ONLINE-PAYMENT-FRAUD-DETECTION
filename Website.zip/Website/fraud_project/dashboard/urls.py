from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('report/<int:report_id>/', views.report_detail, name='report_detail'),
    path('history/', views.report_history, name='history'),
    path('analytics/', views.analytics_dashboard, name='analytics'),
    path('download/<int:report_id>/', views.download_csv, name='download_csv'),
    path('delete/<int:report_id>/', views.delete_report, name='delete_report'),
]
