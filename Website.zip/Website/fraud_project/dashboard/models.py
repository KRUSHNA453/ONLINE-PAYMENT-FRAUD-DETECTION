from django.db import models

class AnalysisReport(models.Model):
    upload_date = models.DateTimeField(auto_now_add=True)
    filename = models.CharField(max_length=255)
    total_transactions = models.IntegerField()
    fraud_transactions = models.IntegerField()
    amount_at_risk = models.DecimalField(max_digits=20, decimal_places=2)

    def __str__(self):
        return f"{self.filename} ({self.upload_date.strftime('%Y-%m-%d')})"

class TransactionItem(models.Model):
    report = models.ForeignKey(AnalysisReport, on_delete=models.CASCADE, related_name='items')
    step = models.IntegerField()
    type = models.CharField(max_length=50)
    amount = models.FloatField()
    oldbalanceOrg = models.FloatField()
    newbalanceOrig = models.FloatField()
    oldbalanceDest = models.FloatField()
    newbalanceDest = models.FloatField()
    is_fraud_prediction = models.BooleanField()
    fraud_probability = models.FloatField()

    class Meta:
        indexes = [
            models.Index(fields=['is_fraud_prediction']),
            models.Index(fields=['type']),
        ]
class Transaction(models.Model):
    step = models.IntegerField()
    type = models.CharField(max_length=20)
    amount = models.FloatField()
    nameOrig = models.CharField(max_length=100)
    oldbalanceOrg = models.FloatField()
    newbalanceOrig = models.FloatField()
    nameDest = models.CharField(max_length=100)
    oldbalanceDest = models.FloatField()
    newbalanceDest = models.FloatField()
    is_fraud_prediction = models.BooleanField(null=True)
    fraud_probability = models.FloatField(null=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.type} - {self.amount}"