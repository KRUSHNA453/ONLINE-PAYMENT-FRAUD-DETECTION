import os
import joblib
import pandas as pd
import numpy as np
from tensorflow.keras.models import load_model
from django.conf import settings

# Paths to artifacts
MODEL_PATH = os.path.join(settings.BASE_DIR, 'dashboard/ml_models/fraud_model.h5')
SCALER_PATH = os.path.join(settings.BASE_DIR, 'dashboard/ml_models/scaler.pkl')

class FraudPredictor:
    def __init__(self):
        self.model = load_model(MODEL_PATH)
        self.scaler = joblib.load(SCALER_PATH)
        # Columns expected by the model after One-Hot Encoding
        self.model_columns = [
            'step', 'amount', 'balance_diff_org', 'balance_diff_dest',
            'type_CASH_OUT', 'type_DEBIT', 'type_PAYMENT', 'type_TRANSFER'
        ]

    def preprocess(self, data):
        # 1. Create Feature Engineering (Balance Diff)
        # Note: Input expects oldBalanceOrg, newBalanceOrig, etc.
        data['balance_diff_org'] = data['newbalanceOrig'] - data['oldbalanceOrg']
        data['balance_diff_dest'] = data['newbalanceDest'] - data['oldbalanceDest']

        # 2. Select Scaling Columns
        num_cols = ['amount', 'balance_diff_org', 'balance_diff_dest']
        
        # 3. Prepare DataFrame with all model columns initialized to 0
        df_processed = pd.DataFrame(0, index=np.arange(len(data)), columns=self.model_columns)
        
        # 4. Fill Numerical Data
        df_processed['step'] = data['step']
        df_processed[num_cols] = self.scaler.transform(data[num_cols])

        # 5. Handle One-Hot Encoding manually to ensure column consistency
        # E.g., if type is 'TRANSFER', set 'type_TRANSFER' to 1
        for i, row in data.iterrows():
            trans_type = row['type']
            col_name = f"type_{trans_type}"
            if col_name in df_processed.columns:
                df_processed.loc[i, col_name] = 1
                
        return df_processed

    def predict(self, input_data):
        # input_data should be a DataFrame
        processed_data = self.preprocess(input_data)
        
        # Prediction (0 to 1 probability)
        probabilities = self.model.predict(processed_data)
        
        # Convert to binary class (Threshold 0.5)
        predictions = (probabilities > 0.5).astype(int)
        
        return probabilities, predictions